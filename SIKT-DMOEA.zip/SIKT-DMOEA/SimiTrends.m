function [exist, STIndex] = SimiTrends(STPool,CurrentSD)

Cols = length(STPool); 
Cols = Cols - 1;
startCol = max(Cols - 50 + 1,1);
utilData = STPool(startCol:Cols);
sigma = 0.1;

remain_cols = startCol - 1;

for i = 1:length(utilData)
    if abs(utilData{i} - CurrentSD) < sigma
        exist = true;
        STIndex = remain_cols + i;
        break;
    else
        exist = false;
        STIndex = -1;
    end
end

end