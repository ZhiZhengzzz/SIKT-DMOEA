function [flag,OP,similar_envir] = SimilarityIdentification(Problem,Population,Delta,OP,t,detectors)

Normal_X_sds_Objs = [];
Grid_Gap = {};
epsilon = 0.1;

X_sds = Problem.Evaluation(detectors);

X_sds_Objs = X_sds.objs;

Max_Obj = max(X_sds_Objs);
Min_Obj = min(X_sds_Objs);

Normal_Objs_i = (X_sds_Objs - Min_Obj) ./ (Max_Obj - Min_Obj);
Normal_X_sds_Objs = [Normal_X_sds_Objs ; Normal_Objs_i];

Scale = 1 / Delta;
for i = 0:(1/Scale - 1)
    g = [i * Scale, (i+1) * Scale];
    Grid_Gap{end + 1} = g;
end

Current_Env_Xsds_OP = zeros(Problem.M,Delta);
for m = 1:Problem.M
    Normal_Objs_m = Normal_X_sds_Objs(:,m);
    m_OP = zeros(1,Delta);
    for i = 1:size(Normal_Objs_m,1)
        for j = 1:size(Grid_Gap,2)
            if j < Delta
                if Normal_Objs_m(i) >= Grid_Gap{j}(1) && Normal_Objs_m(i) < Grid_Gap{j}(2)
                    m_OP(1,j) = m_OP(1,j) + 1;
                    break;
                end
            else
                m_OP(1,Delta) = m_OP(1,Delta) + 1;
            end
        end
    end
    Current_Env_Xsds_OP(m,:) = m_OP ./ size(X_sds,2);
end

OP{end+1} = Current_Env_Xsds_OP;
SD_List = [];
flag = 0;

if t < 1
    similar_envir = -1;
else
    KL = [];
    for k = (size(OP,2)-1):-1:1
        K_OP = OP{k};
        for i = 1:Problem.M
            KL(i) = CalSD(K_OP(i,:),Current_Env_Xsds_OP(i,:));
        end

        SD_k_t = mean(KL,2);
        SD_List(end+1) = SD_k_t;

        if SD_k_t < epsilon
            similar_envir = k;
            flag = k;
            break;
        end
    end
    if flag
        similar_envir = flag;

    else
        similar_envir = -1;
    end

end

end

function Similarity_Degree = CalSD(Pk,Pt)
Similarity_Degree = sum(Pk .* log2(Pk ./ Pt), 'omitnan');
end

