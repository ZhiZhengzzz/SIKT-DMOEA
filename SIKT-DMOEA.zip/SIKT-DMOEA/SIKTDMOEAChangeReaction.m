function Population = SIKTDMOEAChangeReaction(Problem,Population,NC,NC_Dir,non_dominated_Population,dominated_Population,idx,C,K,isMatch,similar_envir,POSs,t)
% React to the environmental change

%------------------------------- Copyright --------------------------------
% Copyright (c) 2022 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------



non_dominated_Population_copy = non_dominated_Population;


reEvasimiPop = SOLUTION.empty;

if isMatch
    simiPop = POSs{similar_envir};
    simi_bests_size = size(simiPop,2);
    simiN = floor((1 - 0.5*simi_bests_size/Problem.N)*simi_bests_size);
    reEvasimiPop = Problem.Evaluation(simiPop(1, randperm(simi_bests_size,simiN)).decs);
    rest_size = Problem.N - simiN;
end

if t==0
    PopSize = Problem.N;
    RandomNum = ceil(PopSize/5);
    p1 = Problem.Initialization(RandomNum);
    p2 = Population(randperm(Problem.N,(Problem.N-RandomNum)));
    p2 = Problem.Evaluation(p2.decs);
    [Population,~,~] = EnvironmentalSelection_NSGAII([p1,p2],Problem.N);

else

    for i=1:K
        employ_index = find(idx==i);
        employ_decs = non_dominated_Population(employ_index).decs;
        new_nds_dec = employ_decs - rand.*NC_Dir(i,:);

        for j =1 : Problem.D
            if  new_nds_dec(j) < Problem.lower(j)
                new_nds_dec(j) = rand * (Problem.upper(j) - Problem.lower(j)) + Problem.lower(j);
            end
            if  new_nds_dec(j)> Problem.upper(j)
                new_nds_dec(j) = rand * (Problem.upper(j) - Problem.lower(j)) + Problem.lower(j);
            end
        end
        non_dominated_Population(employ_index) = Problem.Evaluation(new_nds_dec);
    end


    if ~isempty(dominated_Population)

        dp_size = size(dominated_Population,2);

        for i = 1:dp_size
            dp_dis_cc = pdist2(dominated_Population(i).decs, C, 'euclidean');
            [~,associate1] = min(dp_dis_cc,[],2);

            dp_dis_ndp = pdist2(dominated_Population(i).decs, non_dominated_Population_copy.decs, 'euclidean');
            [~,associate2] = min(dp_dis_ndp,[],2);
            r1 = rand;
            r2 = 1 - r1;
            new_ds_dec = dominated_Population(i).decs + r1.*NC_Dir(associate1,:) + r2.*(non_dominated_Population_copy(associate2).decs - dominated_Population(i).decs);
            for j =1 : Problem.D
                if  new_ds_dec(j) < Problem.lower(j) || new_ds_dec(j) > Problem.upper(j)
                    new_ds_dec(j) = rand * (Problem.upper(j) - Problem.lower(j)) + Problem.lower(j);
                end
            end

            dominated_Population(i) = Problem.Evaluation(new_ds_dec);
        end

    end

    Population1 = [non_dominated_Population,dominated_Population];    % N


    if isMatch
        Population2 = Problem.Evaluation(Population(1,randperm(Problem.N,ceil(0.5*rest_size))).decs);
        randPop = Problem.Initialization(rest_size - ceil(0.5*rest_size));
        [Population,~,~] = EnvironmentalSelection_NSGAII([Population1,Population2,randPop,reEvasimiPop],Problem.N);
    else
        Population2 = Problem.Evaluation(Population(1, randperm(Problem.N, round(0.5*Problem.N))).decs);     % 0.5N，
        randPop = Problem.Initialization(Problem.N - round(0.5*Problem.N));                                            % 0.5N
        [Population,~,~] = EnvironmentalSelection_NSGAII([Population1,Population2,randPop],Problem.N);
    end



end

end