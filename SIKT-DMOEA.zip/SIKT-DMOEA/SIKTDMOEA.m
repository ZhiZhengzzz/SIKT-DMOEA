classdef SIKTDMOEA < ALGORITHM
    % <multi> <real/integer/label/binary/permutation> <constrained/none> <dynamic>
    % MLP + MOEAD/DE for dynamic multi-objective problems

    %------------------------------- Copyright --------------------------------
    % Copyright (c) 2022 BIMK Group. You are free to use the PlatEMO for
    % research purposes. All publications which use this platform or any code
    % in the platform should acknowledge the use of "PlatEMO" and reference "Ye
    % Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
    % for evolutionary multi-objective optimization [educational forum], IEEE
    % Computational Intelligence Magazine, 2017, 12(4): 73-87".
    %--------------------------------------------------------------------------
 methods
        function main(Algorithm,Problem)
            %% Generate random population
            % Initialization
            Population = Problem.Initialization();
            % Population size
            PopSize = Problem.N;
            % Initialize
            MLP = RGM_D(Problem);
            detectors = Population(1,randperm(PopSize,floor(Problem.N/10))).decs;
            POSs = {};
            K = 8;
            Cluster_Centroid = {};
            AllMLP = {};
            NC = [];
            NC_Dir = [];
            Delta = 20; 
            OP = {}; 
            t = 0;
            % Archive for storing all populations before each change
            AllPop = [];
            % Parameter setting
            [delta,nr] = Algorithm.ParameterSet(0.9,2);
            % Generate the weight vectors
            [W,Problem.N] = UniformPoint(Problem.N,Problem.M);
            T = ceil(Problem.N/10);
            % Detect the neighbours of each solution
            B = pdist2(W,W);
            [~,B] = sort(B,2);
            B = B(:,1:T);
            Z = min(Population.objs,[],1);

            KLPool = {};
            exist = false;
            STPool = {};
            [~,OP,~] = SimilarityIdentification(Problem,Population,Delta,OP,t,detectors);

            for generation = 1:50
                for i = 1 : Problem.N
                    % Choose the parents
                    if rand < delta
                        P = B(i,randperm(end));
                    else
                        P = randperm(Problem.N);
                    end
                    % Generate an offspring
                    Offspring = OperatorDENoEva(Problem,Population(i),Population(P(1)),Population(P(2)));
                    % Update the ideal point
                    Z = min(Z,Offspring.obj);
                    % Update the solutions in P by Tchebycheff approach
                    g_old = max(abs(Population(P).objs-repmat(Z,length(P),1)).*W(P,:),[],2);
                    g_new = max(repmat(abs(Offspring.obj-Z),length(P),1).*W(P,:),[],2);
                    Population(P(find(g_old>=g_new,nr))) = Offspring;
                end 
            end
            
            %% Optimization
            while Algorithm.NotTerminated(Population)
                if Changed(Problem,Population) 
                    % Save the population before the change
                    AllPop = [AllPop,Population];

                    [isMatch,OP,similar_envir] = SimilarityIdentification(Problem,Population,Delta,OP,t,detectors);

                    AdjacentSD = CalAdjacentSD(Problem,OP);
                    STPool{end+1} = AdjacentSD;

                    POSs{end+1} = Population.best;

                    non_dominated_Population = Population.best;
                    dominated_Population = SOLUTION.empty;
                    for i = 1:Problem.N
                        if ~ismember(Population(i), non_dominated_Population)
                            dominated_Population(end+1) = Population(i);
                        end
                    end

                    if t > 0
                        [idx,C] = GetCluster(non_dominated_Population,K,2);
                        Cluster_Centroid{end+1} = C;
                        if size(non_dominated_Population,2) < K
                            SupplementNum = K - size(non_dominated_Population,2);
                            [FrontNo, ~] = NDSort(Population.objs,Population.cons,Problem.N);
                            CrowdDis = CrowdingDistance(Population.objs,FrontNo);
                            ind2 = FrontNo == 2;
                            Rank2 = Population(ind2);
                            Rank2CrowdDis = CrowdDis(ind2);
                            [~, RankC] = sort(Rank2CrowdDis,'descend');
                            SupplementC = Rank2(RankC(1:SupplementNum));
                            C = [C; SupplementC.decs];
                            Cluster_Centroid{end} = C;
                        end


                    else  % t=0
                        [idx, C] = GetCluster(non_dominated_Population,K,2);
                        Cluster_Centroid{end+1} = C;
                    end
                    
                    if t > 0
                        [exist, STIndex] = SimiTrends(STPool,STPool{end});
                        
                        if exist
                            if STIndex-1 == length(AllMLP)
                                [LC, CC] = CenDataCreate(Cluster_Centroid,t);
                                MLP = RGM_D(Problem,'batch_size',2);
                                [MLP,~] = RGM_D_train(MLP,LC,CC);
                                NC = RGM_D_pridict(MLP,CC);
                                NC_Dir = NC - CC;
                                AllMLP{end+1} = MLP;
                            else
                                [LC, CC] = CenDataCreate(Cluster_Centroid,t);
                                MLP = AllMLP{STIndex};
                                MLP.lr = 0.001; 
                                MLP.epoch = 32;    
                                [MLP,~] = RGM_D_train(MLP,LC,CC);
                                NC = RGM_D_pridict(MLP,C);
                                NC_Dir = NC - C;
                            end
                            
                        else
                            [LC, CC] = CenDataCreate(Cluster_Centroid,t);
                            MLP = RGM_D(Problem,'batch_size',8);
                            [MLP,~] = RGM_D_train(MLP,LC,CC);
                            NC = RGM_D_pridict(MLP,CC);
                            NC_Dir = NC - CC;

                            AllMLP{end+1} = MLP;
                        end
                    end

                    Population = SIKTDMOEAChangeReaction(Problem,Population,NC,NC_Dir,non_dominated_Population,dominated_Population,idx,C,K,isMatch,similar_envir,POSs,t);
                    t = t + 1;
                    
                end

                for i = 1 : Problem.N
                    % Choose the parents
                    if rand < delta
                        P = B(i,randperm(end));
                    else
                        P = randperm(Problem.N);
                    end
                    % Generate an offspring
                    Offspring = OperatorDE(Problem,Population(i),Population(P(1)),Population(P(2)));
                    % Update the ideal point
                    Z = min(Z,Offspring.obj);
                    % Update the solutions in P by Tchebycheff approach
                    g_old = max(abs(Population(P).objs-repmat(Z,length(P),1)).*W(P,:),[],2);
                    g_new = max(repmat(abs(Offspring.obj-Z),length(P),1).*W(P,:),[],2);
                    Population(P(find(g_old>=g_new,nr))) = Offspring;
                end

                if Problem.FE >= Problem.maxFE               
                    Population = [AllPop,Population];
                    [~,rank]   = sort(Population.adds(zeros(length(Population),1)));
                    Population = Population(rank);
                end
            end
        end
    end 

end







