classdef RGM_D
    properties 
        Problem 
        epoch
        batch_size
        velocity
        lr
        net
        gpu
    end

    methods
        %% Constructor
        function obj = RGM_D(Problem,varargin)

            Parser = inputParser;    
            addRequired(Parser,'Problem');
            addOptional(Parser,'epoch',40);
            addOptional(Parser,'batch_size',8);    
            addOptional(Parser,'hiddim',8);       
            addOptional(Parser,'lr',0.01);     
            parse(Parser,Problem,varargin{:});
            obj.Problem   = Problem;

            obj.epoch = Parser.Results.epoch;
            obj.batch_size = Parser.Results.batch_size;
            obj.lr = Parser.Results.lr;
            obj.velocity = [];    

            lgraph = layerGraph();   

            XLayers = [
                featureInputLayer(Problem.D,"Name","featureinput_X")    
                fullyConnectedLayer(Parser.Results.hiddim)              
                sigmoidLayer()                                          
                fullyConnectedLayer(Problem.D)                          
                ];

            lgraph = addLayers(lgraph,XLayers);                         
            obj.net = dlnetwork(lgraph);                                
        end

        function [obj,avgloss] = RGM_D_train(obj,LC,CC)

            LCN = size(LC,1);   
            CCN = size(CC,1);
            Lower = repmat(obj.Problem.lower,LCN,1);    
            Upper = repmat(obj.Problem.upper,LCN,1);
            LC = (LC-Lower) ./ (Upper-Lower);

            Lower = repmat(obj.Problem.lower,CCN,1);
            Upper = repmat(obj.Problem.upper,CCN,1);
            CC = (CC-Lower) ./ (Upper-Lower);

            options = trainingOptions('adam', ...
                'Plots','none', ...
                'MaxEpochs', 40, ...  
                'MiniBatchSize', 8, ...
                'Shuffle', 'never', ...
                'InitialLearnRate', 0.01, ...
                'LearnRateDropPeriod',20, ...                     
                'LearnRateDropFactor',0.1, ...                 
                'GradientThreshold', 1, ...
                'InputDataFormats', 'BC', ...
                'TargetDataFormats', 'BC', ...
                'ExecutionEnvironment', 'cpu');
            avgloss=0;
            obj.net = trainnet(LC, CC, obj.net, 'mse', options);

        end



        %% 预测修改
        function [NextTC] = RGM_D_pridict(obj,CurrentC)   

            N = size(CurrentC,1); 
            Lower = repmat(obj.Problem.lower,N,1);
            Upper  = repmat(obj.Problem.upper,N,1);
            CurrentC = (CurrentC - Lower) ./ (Upper - Lower);
            X_Predict = dlarray(single(CurrentC)','CB');
            Y = minibatchpredict(obj.net,X_Predict,InputDataFormats='CB');
            NextTC = double(extractdata(Y)');
            NextTC = (NextTC .* (Upper - Lower) + Lower);
            Upper = obj.Problem.upper;
            Lower = obj.Problem.lower;
            NextTC = max(min(NextTC,Upper),Lower);
        end


    end
end