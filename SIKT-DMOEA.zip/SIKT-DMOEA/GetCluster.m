function  [idx,C] = GetCluster(non_dominated_Population,K,thistype)

    ndp_decs = non_dominated_Population.decs;

    if thistype == 1
        [idx,C] = kmeans(non_dominated_Population.objs,K); 

    elseif thistype == 2
        Y = pdist(ndp_decs);
        sY = squareform(Y);
        linsY = linkage(sY);
        idx = cluster(linsY,"maxclust",K);
        C = [];
        for i = 1:K
            C = [C;mean(non_dominated_Population(idx==i).decs,1)];
        end

    elseif thistype == 3
        [idx,C] = kmedoids(non_dominated_Population.decs,K);
    end
    
end