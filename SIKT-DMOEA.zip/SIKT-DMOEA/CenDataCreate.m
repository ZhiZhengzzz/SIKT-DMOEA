function [LC, CC] = CenDataCreate(Cluster_Centroid,t)
    LC = Cluster_Centroid{t-1+1};
    CC = Cluster_Centroid{t+1};   
    K = size(CC,1);

    COCLastT = mean(LC,1);
    COCCurrentT = mean(CC,1);

    CentroidDir = COCCurrentT - COCLastT;

    Omega = zeros(K,K);
    D = zeros(K,K);
    CosSimi = zeros(K,K);
    for i = 1:K
        for j = 1:K
            Vij = CC(i,:) - LC(j,:);
            CosSimi(i,j) = 1 - pdist2(Vij,CentroidDir,'cosine');
        end
    end

    Dmin = 999;
    Dmax = 0;
    for i = 1:K
        for j = 1:K
            D(i,j) = pdist2(LC(i,:),CC(j,:),'euclidean');
            Dmin = min(D(i,j),Dmin);
            Dmax = max(D(i,j),Dmax);
        end
    end

    Omega = exp(abs(CosSimi) - 1);
    [assignment, ~] = munkres(Omega);

    CC = CC(assignment,:);   
    
end