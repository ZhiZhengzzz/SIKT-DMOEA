function AdjacentSD = CalAdjacentSD(Problem,OP)
    LastOP = OP{end-1};
    CurrentOP = OP{end};
    KL = [];
    for i = 1:Problem.M 
        KL(i) = CalSD(LastOP(i,:),CurrentOP(i,:));
    end
    AdjacentSD = mean(KL,2);
end

function Similarity_Degree = CalSD(Pk,Pt)
    Similarity_Degree = sum(Pk .* log2(Pk ./ Pt), 'omitnan');
end